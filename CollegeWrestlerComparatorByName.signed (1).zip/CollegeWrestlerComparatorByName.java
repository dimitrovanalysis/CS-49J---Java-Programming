import java.util.Comparator;

public class CollegeWrestlerComparatorByName implements Comparator<CollegeWrestler>
{
   public int compare(CollegeWrestler firstWrestler,CollegeWrestler secondWrestler)
   {
      
      return (firstWrestler.getName().compareTo(secondWrestler.getName()));
   }
}