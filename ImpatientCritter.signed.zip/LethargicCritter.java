/**
 * lethargiccritter subclass of critter superclass
 * @author Konstantin
 *
 */


public class LethargicCritter extends Critter
{

  
    boolean other=false;
  
    
    /**
     * auto gen. constructor for lethargiccritter using super class critter
     * @param weight given weight
     */
   public LethargicCritter(double weight) 
   {
       super(weight);
   }
  
   
   /**
    * override method that takes user provided moves 
    * doesnt need them- uses boolean other
    * @param moves the user provided moves
    */
   @Override public void move(int moves)
    {
      
       if(!other)
       {
    	   super.addHistory("eat");
    	   other =!false;
       }
       else
       {
           super.addHistory("sleep");
           other=!true;
       }
    }
  

  


}