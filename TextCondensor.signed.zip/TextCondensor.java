import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class TextCondensor 
{
   private ArrayList<String> list;

   public TextCondensor(ArrayList<String> files) 
   {
       list=files;
   }
   
   
   public Set<String> condenseText() 
   {
       Set<String> set = new TreeSet<>();
     
       set.addAll(list);
       
       return set;
   }


   public void setList(ArrayList<String> files)
   {
       this.list=files;
   }
   
   //would not work with other functions
}