
/**
 * cookie jar class simulating cookie jar with eating and filling
 * @author Konstantin
 *
 */
public class CookieJar
{
	public static final int COOKIE_CAPACITY = 50;
	private int capacity;
	
	/**
	 * constructor for cookie class assigning static vaariable
	 * to fill thecookie jar
	 */
	public CookieJar()
	{
		capacity = COOKIE_CAPACITY;
		
	}
	
	/**
	 * eat method that modifies capacity to account for cookeis eaten
	 * will not work if amount of cookiesEaten is greater than capacity
	 * @param cookiesEaten the number of cookeis eaten
	 */
	public void eat(int cookiesEaten)
	{
		if (0 <= (capacity - cookiesEaten))
				{
				capacity = capacity - cookiesEaten;
				}
		if(0 > (capacity - cookiesEaten))
		{
			capacity = 0;
		}
	}
	
	/**
	 *method that fills the cookie jar back up to capacity 
	 */
	public void fill()
	{
		capacity = COOKIE_CAPACITY;
		
	}
	
	/**
	 * method that returns capacity
	 * @return returns the capacity
	 */
	public int getAmount()
	{
		return capacity;
		
	}
}