
public class ProductOverrideTester
{

   public static void main(String[] args)
   {
      //Testing toString
      Product watch = new Product("Apple Watch", 269);
      System.out.println(watch); //same as watch.toString()
      
//      Painting stars = new Painting("The Starry Night", 350, "Van Gogh");
//      System.out.println(stars);
 
//      //testing equals
//       Product watch2 = new Product("Apple Watch", 269);
//       Product watch3 = new Product("Apple Watch", 379);
//
//       System.out.println(watch.equals(watch2));
//       System.out.println("Expected: true");
//       System.out.println(watch.equals(watch3));
//       System.out.println("Expected: false");
//      
//        //equals problem1
//     System.out.println(watch.equals("ABC"));
//      
////      //equals problem2
//      Product product = new Product("The Starry Night", 350.05);
//      Painting painting = new Painting("The Starry Night", 350.05, "Van Gogh");
//      
//      System.out.println(product.equals(painting));
//      System.out.println("Expected: false");
//      
////      //subclass equals
//      Painting painting2 = new Painting("The Starry Night", 350.05, "Van Gogh");
//      Painting painting3 = new Painting("Stars", 350.05, "Van Gogh");
//      
//      System.out.println("subclass: " + painting.equals(painting2));
//      System.out.println("Expected: true");
//      System.out.println("subclass: " + painting.equals(painting3));
//      System.out.println("Expected: false");
   }
}
