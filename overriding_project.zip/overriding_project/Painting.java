//SOLUTION
/**
 * Describes a Painting with an artist
 */
public class Painting extends Product
{
    private String artist;

    /**
     * Constructs a Painting 
     * @param thePrice the price of this Painting
     * @param theDescription - the title of this Painting
     * @param artist the artist of this Painting
     */
    public Painting(String theDescription, double thePrice, String artist)
    {
        super(theDescription, thePrice);
        this.artist = artist;
    }
    
    /**
     * Determines if this Painting as the same artist as 
     * the given Painting
     * @param other the other Painting object
     * @return true if the Paintings have the same artist. 
     * Otherwise, false
     */
    public boolean sameAuthor(Painting other)
    {
        if (this.artist.equals(other.artist))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    
    @Override
    public String getDescription()
    {
        String s = super.getDescription()
            + " " + artist;
        return s;
    }
    
    /**
     * Gets the name of the author of this Painting
     * @return the name of the author of this Painting
     */
    public String getArtist()
    {
        return artist;
    }

}

