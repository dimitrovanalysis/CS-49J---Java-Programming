/**
 * Models a player of the game Fizzbin
 * @author Konstantin
 *
 */

public class FizzbinPlayer
{
	
	private String name;
	private double adjustmentValue;
	
	/**
	 * FizzbinPlayer constructor sets initial name and adjustment value
	 * @param theName the name of the player
	 * @param theAdjustmentValue the amount adjusted
	 */
	public FizzbinPlayer(String theName, double theAdjustmentValue)
	{
		name = theName; 
		adjustmentValue = theAdjustmentValue;
		
	}
	
	/**
	 * method provides name of player
	 * @return returns the name of the player
	 */
	
	public String getName()
	{
		return name;
		
	}
	
	
	/**
	 * method returns the value you're adjusting by
	 * @return returns the adjustmentValue
	 */
	public double getAdjustment()
	{
		return adjustmentValue;
		
	}
	
	
	/**
	 * sets the adjustmentvalue to a new adjustment value
	 * @param theAdjustmentValue the new adjustment value you're setting
	 */
	public void setAdjustment(double theAdjustmentValue)
	{
		
		adjustmentValue = theAdjustmentValue;
		
	}
	
	
}
