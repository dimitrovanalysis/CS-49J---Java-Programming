#include <iostream>
#include <string>
#include "ArrayStack.h"
using namespace std;


void infixToPost(string infix){
char x;
char y;
bool check;
StackInterface<char>* stackPtr = new ArrayStack<char>();
for(unsigned int i = 0; i<infix.length(); i++) {

	char c = infix[i]; //this is your character
	int j = c - '0';

		if ( j < 10 && j >= 0 ) //  seperating operands from operators
		cout << c ; // step 1) appendage 

		else if ( c == '(')
		stackPtr->push(c); // step2) if (, push onto stack

		else if ( c == ')'){
		x = stackPtr -> peek();
		
			while( x != '('){
			cout << x;
			stackPtr -> pop();
			}	

		stackPtr -> pop(); // pop off the '('

		}
		
		else if ( c == 0){
			check = stackPtr -> isEmpty();
			while(!check)
			check = stackPtr -> isEmpty();
			x = stackPtr-> peek();
			cout << x;
			stackPtr -> pop();
		}
		
		
		else if ( c == '+' || c == '-' || c == '*' || c == '/' ){

			if( stackPtr -> isEmpty())
			stackPtr->push(c);

			else{
			x = stackPtr->peek();
			cout << x << endl;

				if(x != '(' || stackPtr->isEmpty()!= true ){
		
				if ( x == '*' || x == '/'){ //these will always be "greater or equal"
					cout << x;
					stackPtr->pop();
					
					}

				if ( x == '+' || x == '-' ){
						
						if ( c == '+' || c == '-' ){
						cout << x;
						stackPtr->pop();
						
						}
						
						
											
					}
					
				}
				
			}
				

		}

		


}

}


void calculatePostfix(string postfix){
int op1;
int op2;
StackInterface<char>* stackPtr = new ArrayStack<char>();

	for(unsigned int i = 0; i< postfix.length(); i++) {
        char c = postfix[i]; //this is your character in ascii
        stackPtr->push(c); // push all char onto stack (already in postfix)
	}

	for(unsigned int i = 0; i<postfix.length(); i++) {
	char c = postfix[i];

	 	if (c == '+'){
		stackPtr->pop();
		op1 = stackPtr-> peek();
		op1 = op1 - '0';
		stackPtr->pop();
		op2 = stackPtr-> peek();
		op2 = op2 - '0'; 
		stackPtr->pop();
		int partial = op1 + op2;
		stackPtr->push(partial);
		}

		else if (c == '-'){
		stackPtr->pop();
                op1 = stackPtr-> peek();
                op1 = op1 - '0';
                stackPtr->pop();
                op2 = stackPtr-> peek();
                op2 = op2 - '0';
                stackPtr->pop();
		int partial1 = op2 - op1;
		stackPtr -> push(partial1);
		}

		else if (c == '*'){
                stackPtr->pop();
                op1 = stackPtr-> peek();
                op1 = op1 - '0';
                stackPtr->pop();
                op2 = stackPtr-> peek();
                op2 = op2 - '0';
                stackPtr->pop();
		int partial2 = op1 * op2;
		stackPtr-> push(partial2);
		}

		else if (c == '/'){
                stackPtr->pop();
                op1 = stackPtr-> peek();
                op1 = op1 - '0';
                stackPtr->pop();
                op2 = stackPtr-> peek();
                op2 = op2 - '0';
                stackPtr->pop();
		int partial3 = op2 / op1;
		stackPtr -> push(partial3);
		}

        }
       int result = stackPtr->peek(); //result at top of stack
        cout << "your result is " << result << endl;

}




int main()
{
 string anItem = "";
 cout << "Enter a string: ";
 cin >> anItem; // Read an item
 cout << "Will now display string in postfix format " << endl;
 infixToPost(anItem);
 cout << endl;
 cout << "please enter in the postfix expression above exactly as shown " << endl;
 cout << "please also add your 1 operator needed to the end" << endl;
 cout << "if more than 1 operator, run the program for each operator," << endl;
 cout << "take note of the programs previous result, and apply it in the next run" << endl;
 cin >> anItem;
 calculatePostfix(anItem);


// stackPtr->push(anItem);

return 0;
}


